/* Kevin Holz, s77179, 041/61/17 */

#ifndef FINALLEXER_CODEGEN_H
#define FINALLEXER_CODEGEN_H

#endif //FINALLEXER_CODEGEN_H

int st1();
int st2();
int st3();

int bl1();
int bl2();
int bl3();
int bl4();
int bl5();
int bl6();

int fa1();
int fa2();

int pr1();
